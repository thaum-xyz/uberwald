declare module 'colorthief';
