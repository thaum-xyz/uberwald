var galleryImages = document.querySelectorAll( '.kg-gallery-image img' );
galleryImages.forEach( function ( image ) {
	var container = image.closest( '.kg-gallery-image' );
	var width = image.attributes.width.value;
	var height = image.attributes.height.value;
	var ratio = width / height;
	container.style.flex = ratio + ' 1 0%';
})