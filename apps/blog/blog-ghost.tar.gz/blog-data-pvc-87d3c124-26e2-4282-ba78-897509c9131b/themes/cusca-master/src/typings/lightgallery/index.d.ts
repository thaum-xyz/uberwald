// Lightgallery.js

interface Window {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    lightGallery: (el: Element, options: any) => void;
}
