// particlesJS

interface Window {
    // eslint-disable-next-line @typescript-eslint/camelcase,@typescript-eslint/no-explicit-any
    particlesJS: (tag_id: string, params: any) => void;
}
