// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function GhostSearch(args: any): void;
export as namespace GhostSearch;
