declare module '@tryghost';
